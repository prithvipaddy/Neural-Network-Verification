# tensors

[![Hackage](https://img.shields.io/hackage/v/tensors.svg)](https://hackage.haskell.org/package/tensors)
[![stackage LTS package](http://stackage.org/package/tensors/badge/lts)](http://stackage.org/lts/package/tensors)
[![stackage Nightly package](http://stackage.org/package/tensors/badge/nightly)](http://stackage.org/nightly/package/tensors)
[![Build Status](https://travis-ci.org/leptonyu/tensors.svg?branch=master)](https://travis-ci.org/leptonyu/tensors)


Type level tensors in Haskell.
